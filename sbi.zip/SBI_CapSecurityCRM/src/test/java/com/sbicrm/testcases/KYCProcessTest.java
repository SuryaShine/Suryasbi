package com.sbicrm.testcases;

import java.text.DecimalFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.excel.utility.Xls_Reader;

public class KYCProcessTest {

public static	WebDriver driver=null;
	


By emailId = By.xpath("//input[@class='textbox' and @name='UserName']");
By password = By.xpath("//input[@id='TxtPassword' ]");
By loginButton = By.xpath("//input[@value='login' ]");

@Test(priority=1)
	public void loginCRM() throws InterruptedException {
		
		  
System.setProperty("webdriver.chrome.driver","E:\\Gargi\\Selenium\\Drivers\\Chrome Driver\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\eclipse-workspace\\SBI_CapSecurityCRM\\Drivers\\chromedriver.exe");
		
	     driver = new ChromeDriver();
		
	  //Maximizes the browser window
	  		driver.manage().window().maximize();
	    
		// launch Chrome and redirect it to the Base URL
		driver.get("https://crmn.sbismart.com/bcg/sn/app/login/login?logout=1");
		
		
		
		
		driver.findElement(emailId).clear();
		driver.findElement(emailId).sendKeys("br_anitad");
		driver.findElement(password).clear();
		driver.findElement(password).sendKeys("acid_qa");
		driver.findElement(loginButton).click();
		
    
}
     
	
		Xls_Reader reader = new Xls_Reader("C://Users//User//eclipse-workspace//SBI_CapSecurityCRM//src//main//java//com//crm//qa//testdata//SbiCRMUATList.xlsx");
		
		int rowCount = reader.getRowCount("Shine");
		
		
By searchBtn1st= By.xpath("//i[@class='icon icon-header-search-bar-icon']");
		
		By txtLeadId  = By.xpath("//input[@id='LeadID']");
		
		By searchBtn2nd= By.xpath("//input[@id='srchBtn']");
		
		By editBtn= By.xpath("//a[@id='BTN_EDIT']//i[@class='icon icon-edit']");
		
		   By callStatus1= By.xpath("//select[@id='LEA_EX2_63']");
		   By callStatus2= By.xpath("//select[@id='LEA_EX2_64']");
		   By callStatus3= By.xpath("//select[@id='LEA_EX2_65']");
		   By callStatus4= By.xpath("//select[@id='LEA_EX2_66']");
		   By SaveAndProceedBtn= By.xpath("//span[contains(text(),'Save and Proceed')]");
		
		   
		  
        @Test(priority=2)	
		public void activeCallstatus() throws InterruptedException {
		for(int rowNum=2; rowNum<=rowCount; rowNum++) {
			
			Thread.sleep(2000);
		 driver.findElement(searchBtn1st).click();	
		Thread.sleep(2000);
		
		String leadIdstr = reader.getCellData("Shine", "LEADID", rowNum);
		
		System.out.println(leadIdstr);
		
		Double leadId1 = Double.valueOf(leadIdstr);
		System.out.println(leadId1);
		
		//int leadId=Integer.parseInt(leadId1); 
		
		int leadId2 = leadId1.intValue();
		
		System.out.println(leadId2);
		
		String leadId = Integer.toString(leadId2); 
		System.out.println(leadId);
		
		
		Thread.sleep(2000);
		driver.findElement(txtLeadId).clear();
		Thread.sleep(2000);
		driver.findElement(txtLeadId).sendKeys(leadId);
		
		Thread.sleep(2000);
		driver.findElement(searchBtn2nd).click();
		
		
		Thread.sleep(1000);
	driver.findElement(editBtn).click();
	Thread.sleep(1000);
		
	Select dropdown1 = new Select(driver.findElement(callStatus1)); 
	dropdown1.selectByVisibleText("Picked Up");
	
	
	Select dropdown2 = new Select(driver.findElement(callStatus2)); 
	
	dropdown2.selectByVisibleText("Right Person");
	
	Thread.sleep(2000);
		
	Select dropdown3 = new Select(driver.findElement(callStatus3)); 
	dropdown3.selectByVisibleText("Not Busy");
	
	Select dropdown4 = new Select(driver.findElement(callStatus4)); 
	dropdown4.selectByVisibleText("Approved For A/c opening - Correct Email ID & Scheme");
	
	Thread.sleep(2000);
	driver.findElement(SaveAndProceedBtn).click();
	Thread.sleep(2000);
	
	reader.setCellData("Shine", "KYCStatus", rowNum, "KYC_Done");
		}
	}
	
	
	
        @Test(priority=3)
        public void callStatusNegative() throws InterruptedException{
        	
        	
        	for(int rowNum=2; rowNum<=rowCount; rowNum++) {
    			
    			Thread.sleep(2000);
    		 driver.findElement(searchBtn1st).click();	
    		Thread.sleep(2000);
    		
    		String leadIdstr = reader.getCellData("Shine", "LEADID", rowNum);
    		
    		System.out.println(leadIdstr);
    		
    		Double leadId1 = Double.valueOf(leadIdstr);
    		System.out.println(leadId1);
    		
    		//int leadId=Integer.parseInt(leadId1); 
    		
    		int leadId2 = leadId1.intValue();
    		
    		System.out.println(leadId2);
    		
    		String leadId = Integer.toString(leadId2); 
    		System.out.println(leadId);
    		
    		
    		Thread.sleep(2000);
    		driver.findElement(txtLeadId).clear();
    		Thread.sleep(2000);
    		driver.findElement(txtLeadId).sendKeys(leadId);
    		
    		Thread.sleep(2000);
    		driver.findElement(searchBtn2nd).click();
    		
    		
    		Thread.sleep(1000);
    	driver.findElement(editBtn).click();
    	Thread.sleep(1000);
    		
    	Select dropdown1 = new Select(driver.findElement(callStatus1)); 
    	dropdown1.selectByVisibleText("Not Picked Up");
    	
    	
    	Select dropdown2 = new Select(driver.findElement(callStatus2)); 
    	
    	dropdown2.selectByVisibleText("Not in used/ Does not exist");
    	
    	Thread.sleep(2000);
    		
    	Select dropdown3 = new Select(driver.findElement(callStatus3)); 
    	dropdown3.selectByVisibleText("Not in used/ Does not exist");
    	
    	Select dropdown4 = new Select(driver.findElement(callStatus4)); 
    	dropdown4.selectByVisibleText("Not in used/ Does not exist");
    	
    	Thread.sleep(2000);
    	driver.findElement(SaveAndProceedBtn).click();
    	Thread.sleep(2000);
    	
    	reader.setCellData("Shine", "KYCStatus", rowNum, "CallStatusNegative");
        	
        	}
        	
        }
        
        @Test(priority=4)
	public void quitBrowser() {
		driver.close();
	}
	
}
