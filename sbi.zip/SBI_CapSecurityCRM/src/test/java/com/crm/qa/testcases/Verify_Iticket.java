package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.IticketPage;
import com.crm.qa.util.TestUtil;

public class Verify_Iticket extends TestBase{

	
	
	IticketPage iticketPage;
	TestUtil testUtil;
	
	
	@Test(priority=1)
	public void login_Verify() {
		initialization();
		iticketPage = new IticketPage();
	}
	
	
	
	@Test(priority=3)
	public void loginTest() {
	
		iticketPage.login_Iticket(prop.getProperty("url_ITicket"),prop.getProperty("username_Verify"), prop.getProperty("password_Verify"));
	}
	
	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"),prop.getProperty("FORM_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	@Test(priority=4,dataProvider="getTestData")
	public void inwardDone(String formId, int rowNo) {
		
		try {
			iticketPage.verify_kcy(formId, rowNo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	
}
	
	
	
	
	
	
