package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.IticketPage;
import com.crm.qa.util.TestUtil;

public class DataEntry extends TestBase{

	IticketPage itiketPage;
	TestUtil testUtil;
	
	
	@Test(priority=1)
	public void login_Inward() {
		initialization();
		itiketPage = new IticketPage();
	}
	
	
	
	@Test(priority=3)
	public void loginTest() {
	
		itiketPage.login_Iticket(prop.getProperty("url_ITicket"),prop.getProperty("username_dataentry"), prop.getProperty("password_dataentry"));
	}
	
	
	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"),prop.getProperty("FORM_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	@Test(priority=4,dataProvider="getTestData")
	public void inwardDone(String formId, int rowNo) {
		
		try {
			itiketPage.dataEntry(formId, rowNo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.assertTrue(false);
		}
		
	}
	
	
	
	
	
	
	
}
