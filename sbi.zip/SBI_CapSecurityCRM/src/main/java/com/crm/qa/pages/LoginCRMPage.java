package com.crm.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.TestUtil;
import com.crm.qa.util.Xls_Reader;

public class LoginCRMPage extends TestBase {
	
	TestUtil testUtil;
	
	//reader = new Xls_Reader(prop.getProperty("TESTDATA_SHEET_PATH"));

	//Page factory -OR:
	
	@FindBy(xpath="//input[@class='textbox' and @name='UserName']")
			WebElement username_crm;
	
	@FindBy(xpath="//input[@id='TxtPassword' ]") WebElement password_crm;
	
	@FindBy(xpath="//input[@value='login' ]") WebElement loginBtn_crm;
	
	@FindBy(xpath="") WebElement Logo_crm;
	
	@FindBy(xpath="//i[@class='icon icon-header-search-bar-icon']") WebElement  topSearchBtn ;
	
	@FindBy(xpath="//input[@id='LeadID']") WebElement txtLeadId;
	
	@FindBy(xpath="//input[@id='srchBtn']") WebElement  searchBtn2nd ;
	
	
	@FindBy(xpath="//div[@class='row row-margin0']//div[4]//span[1]") WebElement kyc_status;
	
	
	@FindBy(xpath="//a[@id='BTN_EDIT']//i[@class='icon icon-edit']") WebElement   editBtn;
	
	@FindBy(xpath="//select[@id='LEA_EX2_63']") WebElement   callStatus1;
	
	@FindBy(xpath="//select[@id='LEA_EX2_64']") WebElement  callStatus2 ;
	
	@FindBy(xpath="//select[@id='LEA_EX2_65']") WebElement   callStatus3;
	
	@FindBy(xpath="//select[@id='LEA_EX2_66']") WebElement  callStatus4 ;
	
	@FindBy(xpath="//span[contains(text(),'Save and Proceed')]") WebElement SaveAndProceedBtn;
	
	

	
	
	//Initializing the Page objects:
	public LoginCRMPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	public String validateLoginPageTitle(){
		return driver.getTitle();
	}
	public boolean  validateCRMImage(){
		return Logo_crm.isDisplayed();
	}
	public void loginCRM(String url,String un ,String pwd)  {
		
		driver.get(url);
		username_crm.sendKeys(un);
		password_crm.sendKeys(pwd);
	
		loginBtn_crm.click();	
	}
	
	
	public   String typeCast(String leadId) {
		
		Double leadIdDbl = Double.valueOf(leadId);
		//System.out.println(leadIdDbl);
		
		//int leadId=Integer.parseInt(leadId1); 
		
		int leadIdItr = leadIdDbl.intValue();
		
		//System.out.println(leadIdItr);
		
		String leadIdStr = Integer.toString(leadIdItr);
		
		return leadIdStr;
	} 
	
	
	public void sendToPreKYC(String leadId, int rowNum) throws Exception {
		
		Thread.sleep(1000);
		topSearchBtn.click();
		
		Thread.sleep(1000);
		
		Double leadIdDbl = Double.valueOf(leadId);
		//System.out.println(leadIdDbl);
		
		//int leadId=Integer.parseInt(leadId1); 
		
		int leadIdItr = leadIdDbl.intValue();
		
		//System.out.println(leadIdItr);
		
		String leadIdStr = Integer.toString(leadIdItr); 
		//System.out.println(leadIdStr);
		
		Thread.sleep(1000);
		txtLeadId.sendKeys(leadIdStr);
		
		testUtil.wait2S();
		searchBtn2nd.click();
		
		
		Thread.sleep(1000);
	editBtn.click();
	Thread.sleep(2000);
		
	Select dropdown1 = new Select(callStatus1); 
	Thread.sleep(1000);
	dropdown1.selectByVisibleText("Picked Up");
	Thread.sleep(1000);
	
	Select dropdown2 = new Select(callStatus2); 
	Thread.sleep(1000);
	
	dropdown2.selectByVisibleText("Right Person");
	
	Thread.sleep(1000);
		
	Select dropdown3 = new Select(callStatus3);
	Thread.sleep(1000);
	dropdown3.selectByVisibleText("Not Busy");
	Thread.sleep(1000);
	Select dropdown4 = new Select(callStatus4); 
	Thread.sleep(1000);
	dropdown4.selectByVisibleText("Approved For A/c opening - Correct Email ID & Scheme");
	Thread.sleep(1000);
	SaveAndProceedBtn.click();
	Thread.sleep(2000);
	
		
	testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("KYC_STATUS"), rowNum, "KYC_Done");
	}
	
	
	public void callStatusNegative(String leadId, int rowNum) throws Exception {
		
		Thread.sleep(1000);
	topSearchBtn.click();
		
	 Thread.sleep(1000);
	
		Double leadIdDbl = Double.valueOf(leadId);
		
		int leadIdItr = leadIdDbl.intValue();
		
		String leadIdStr = Integer.toString(leadIdItr); 
		
		txtLeadId.sendKeys(leadIdStr);
		
		testUtil.wait1S();
		searchBtn2nd.click();
		
		Thread.sleep(1000);
	editBtn.click();
	Thread.sleep(2000);

	
	
	Select dropdown1 = new Select(callStatus1); 
	TestUtil.wait1S();
	dropdown1.selectByVisibleText("Not Picked Up");
	TestUtil.wait1S();
	
	Select dropdown2 = new Select(callStatus2); 
	TestUtil.wait1S();
	dropdown2.selectByVisibleText("Not in used/ Does not exist");
	TestUtil.wait1S();
		
	TestUtil.wait1S();
	Select dropdown3 = new Select(callStatus3); 
	TestUtil.wait1S();
	dropdown3.selectByVisibleText("Not in used/ Does not exist");
	TestUtil.wait1S();
	
	Select dropdown4 = new Select(callStatus4); 
	
	TestUtil.wait1S();
	dropdown4.selectByVisibleText("Not in used/ Does not exist");
	TestUtil.wait1S();
	SaveAndProceedBtn.click();
	Thread.sleep(2000);
	
	testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"),prop.getProperty("KYC_STATUS"), rowNum, "CallStatusNegative");
	TestUtil.wait1S();
	}
	
	
	
	
	
	
	@FindBy(xpath="//span[@id='100030']") WebElement aofRejectedclick;
	
	@FindBy(xpath="//div[@id='WEBR_308']//a[@class='mshuplink list']") WebElement sslMainReasonclick;
	
	@FindBy(xpath="//td[text()='BANK DETAILS MISMATCH']/preceding-sibling::td[1]/input[@type='checkbox']") WebElement sslMReasonSlct;
	
	@FindBy(xpath="//div[@id='WEBR_309']//a[@class='mshuplink list'] ") WebElement sslSubReasonclick;
	
	@FindBy(xpath="//td[text()='BANK DETAILS MISMATCH']/preceding-sibling::td[2]/input[@type='checkbox']") WebElement sslSReasonSlct;
	

	@FindBy(xpath="//i[@class='icon icon-stack']") WebElement  edit1stbtn  ;
	
	@FindBy(xpath="//a[@id='BTN_EDIT_0']//span[contains(text(),'Edit')]") WebElement  edit2ndbtn  ;
	
	//i[@class='icon icon-stack']
	
	
	public void aof_Reject(String leadId, int rowNum) throws Exception {
		
		Thread.sleep(1000);
		topSearchBtn.click();
			
		 Thread.sleep(1000);
		
			Double leadIdDbl = Double.valueOf(leadId);
			
			int leadIdItr = leadIdDbl.intValue();
			
			String leadIdStr = Integer.toString(leadIdItr); 
			
			txtLeadId.sendKeys(leadIdStr);
			
			testUtil.wait1S();
			searchBtn2nd.click();
			
			Thread.sleep(1000);
		//editBtn.click();
			
			//WebElement editBTN= 
			edit1stbtn.click();
			Thread.sleep(1000);
			edit2ndbtn.click();
		Thread.sleep(2000);
		
	//	String kyc_Status= kyc_status.getText();
	//	if(!kyc_Status.contains("Documents sent to KYC") || !kyc_Status.contains("Call Status Negative")) {
		
	aofRejectedclick.click();
	
Thread.sleep(1000);
		
sslMainReasonclick.click();
Thread.sleep(1000);



((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+sslMReasonSlct.getLocation().x+")");
sslMReasonSlct.click();
Thread.sleep(1000);

sslSubReasonclick.click();

Thread.sleep(1000);






List <WebElement> li= driver.findElements(By.xpath("//td[text()='BANK DETAILS MISMATCH']/preceding-sibling::td[2]/input[@type='checkbox']"));
System.out.println(li.size());
        for(int i=0;i<=1;i++)
        {
        	
        	((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+li.get(i).getLocation().x+")");
        	
            li.get(i).click();
        }

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void kyc_TeleCallerProcess(String leadId, int rowNum) throws Exception {
	
		topSearchBtn.click();
		
		Double leadIdDbl = Double.valueOf(leadId);
		//System.out.println(leadIdDbl);
		
		//int leadId=Integer.parseInt(leadId1); 
		
		int leadIdItr = leadIdDbl.intValue();
		
		//System.out.println(leadIdItr);
		
		String leadIdStr = Integer.toString(leadIdItr); 
		//System.out.println(leadIdStr);
		
		txtLeadId.sendKeys(leadIdStr);
		
		testUtil.wait2S();
		searchBtn2nd.click();
		
	//	String kyc_Status= kyc_status.getText();
	//	if(!kyc_Status.contains("Documents sent to KYC") || !kyc_Status.contains("Call Status Negative")) {
		
		
		Thread.sleep(1000);
	editBtn.click();
	Thread.sleep(1000);
		
			if(rowNum >=2 && rowNum <=551) {		
				
			Select dropdown1 = new Select(callStatus1); 
			dropdown1.selectByVisibleText("Picked Up");
			
			
			Select dropdown2 = new Select(callStatus2); 
			
			dropdown2.selectByVisibleText("Right Person");
			
			Thread.sleep(2000);
				
			Select dropdown3 = new Select(callStatus3); 
			dropdown3.selectByVisibleText("Not Busy");
			
			Select dropdown4 = new Select(callStatus4); 
			dropdown4.selectByVisibleText("Approved For A/c opening - Correct Email ID & Scheme");
			
			SaveAndProceedBtn.click();
			Thread.sleep(2000);
			
			testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("KYC_STATUS"), rowNum, "KYC_Done");
				
				
			}else {
				
				Thread.sleep(1000);
				
				Select dropdown1 = new Select(callStatus1); 
				TestUtil.wait2S();
				dropdown1.selectByVisibleText("Not Picked Up");
				TestUtil.wait2S();
				
				Select dropdown2 = new Select(callStatus2); 
				TestUtil.wait2S();
				dropdown2.selectByVisibleText("Not in used/ Does not exist");
				Thread.sleep(2000);
					
				TestUtil.wait2S();
				Select dropdown3 = new Select(callStatus3); 
				TestUtil.wait2S();
				dropdown3.selectByVisibleText("Not in used/ Does not exist");
				TestUtil.wait2S();
				
				Select dropdown4 = new Select(callStatus4); 
				
				TestUtil.wait2S();
				dropdown4.selectByVisibleText("Not in used/ Does not exist");
				TestUtil.wait2S();
				SaveAndProceedBtn.click();
				Thread.sleep(2000);
				
				testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"),prop.getProperty("KYC_STATUS"), rowNum, "CallStatusNegative");
				TestUtil.wait2S();
				
			}
			
			}
			
			
			
		}
		
		
	
	

