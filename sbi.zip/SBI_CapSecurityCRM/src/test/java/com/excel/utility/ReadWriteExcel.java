package com.excel.utility;

import org.testng.annotations.Test;

public class ReadWriteExcel {

	public static void main(String[] args) {
		
		
		Xls_Reader reader = new Xls_Reader("C://Users//User//eclipse-workspace//SBI_CapSecurityCRM//src//main//java//com//crm//qa//testdata//SbiCRMUATList.xlsx");
		
		
		if(!reader.isSheetExist("HomePage")) {
		reader.addSheet("HomePage")	;
		}
		
		
		reader.addColumn("Merged", "TestClmn");
		
		int rowCount = reader.getRowCount("Merged"); 
		
		System.out.println(rowCount);
		
		for(int rowNum=2; rowNum<=10; rowNum++) {
			//reader.getCellData("Merged","LEADID", rowNum);
		reader.setCellData("Merged", "TestClmn", rowNum, "Pass");
		
		System.out.println(rowNum);
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
