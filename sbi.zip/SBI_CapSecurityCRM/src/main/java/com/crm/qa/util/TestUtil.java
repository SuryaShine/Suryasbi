package com.crm.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import com.crm.qa.base.TestBase;


public class TestUtil extends TestBase{
	
//private static Final   File String srcFile  = null;
public static long PAGE_LOAD_TIMEOUT=20;
public static long IMPLICIT_WAIT=30;


public void switchToFrame(){
	driver.switchTo().frame("mainpanel");
}

public static void wait5S() throws Exception{
	Thread.sleep(5000);	
}

public static void wait2S() throws Exception {
		Thread.sleep(2000);		
}

public static void wait1S() throws Exception {
		Thread.sleep(1000);		
}



public static Xls_Reader reader;




public static ArrayList<Object[]>getDataFromExcel(String sheetName, String colName){
	
	ArrayList<Object[]> myData= new ArrayList<Object[]>();
	
	 reader = new Xls_Reader(prop.getProperty("TESTDATA_SHEET_PATH"));
	 
	  int count=reader.getRowCount(sheetName);
	  System.out.println(count);
	
for(int rowNum1=344; rowNum1<=344; rowNum1++) {
	
String cellData=reader.getCellData(sheetName, colName, rowNum1);
if(cellData.isEmpty()) {
	
	//System.out.println("String is empty");
	//rowNum1++;
	continue;
}else 

	System.out.println("String is not empty");



Object ob[]= {cellData,rowNum1};
	myData.add(ob);
}

return myData;
}



public static void takeScreenshotAtEndofTest() throws IOException {
	File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	String currentDir = System.getProperty("user.dir");
			FileUtils.copyFile(srcFile, new File(currentDir+"/screenshots/"+ System.currentTimeMillis()+".png"));	
}

}
