package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.LoginCRMPage;
import com.crm.qa.util.TestUtil;
import com.crm.qa.util.Xls_Reader;

public class AOF_Rejected extends TestBase{

	
	
	
	
	LoginCRMPage login_crmpage;
	
	
	TestUtil testUtil;
	
	public static Xls_Reader reader;

	public AOF_Rejected() {
		super();
	}

	
	  @Test(priority=1) public void login_CRM() { initialization(); login_crmpage =
	  new LoginCRMPage(); }
	 

	
	@Test(priority=2)
	public void loginTest() {
	//	homepage = login_crmpage.loginCRM(prop.getProperty("url_CRM"),prop.getProperty("username_CRM"), prop.getProperty("password_CRM"));
		login_crmpage.loginCRM(prop.getProperty("url_CRM"),prop.getProperty("username_AOF"), prop.getProperty("password_AOF"));
	}

	

	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"), prop.getProperty("LEAD_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	@Test(priority=3,dataProvider="getTestData")
	public void aofReject(String leadId, int romNumber) throws InterruptedException {
		
		try {
			login_crmpage.aof_Reject(leadId, romNumber);
			Assert.assertTrue(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			Assert.assertTrue(true);
		}
		 
		
		
	}
	
	
	
	
	
}
