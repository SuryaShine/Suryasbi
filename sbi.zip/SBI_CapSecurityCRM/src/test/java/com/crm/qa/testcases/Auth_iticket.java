package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.IticketPage;
import com.crm.qa.util.TestUtil;

public class Auth_iticket extends TestBase {

	IticketPage iticketPage;
	TestUtil testUtil;
	
	
	@Test(priority=1)
	public void login_Verify() {
		initialization();
		iticketPage = new IticketPage();
	}
	
	
	
	@Test(priority=3)
	public void loginTest() {
	
		iticketPage.login_Iticket(prop.getProperty("url_ITicket"),prop.getProperty("username_Auth"), prop.getProperty("password_Auth"));
	}
	
	
	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"),prop.getProperty("FORM_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	@Test(priority=4,dataProvider="getTestData")
	public void inwardDone(String formId, int rowNo) {
		
		try {
			iticketPage.authDone(formId, rowNo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
			Assert.assertTrue(false);
		}
		
	}
	
	
	
	
	
	
}
