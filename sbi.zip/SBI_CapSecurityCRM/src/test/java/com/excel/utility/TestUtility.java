    package com.excel.utility;

import java.util.ArrayList;

import com.crm.qa.util.Xls_Reader;

public class TestUtility extends Testbase {
	
	static Xls_Reader reader;
	public static ArrayList<Object[]>getDataFromExcel(){
		
 	ArrayList<Object[]> myData= new ArrayList<Object[]>();
	
		// reader = new Xls_Reader("C://Users//User//eclipse-workspace//SBI_CapSecurityCRM//src//main//java//com//crm//qa//testdata//SbiCRMUATList.xlsx");
		 
		 reader = new Xls_Reader(prop.getProperty("TESTDATA_SHEET_PATH"));
		
		  int count=reader.getRowCount("Merged");
		  System.out.println(count);
		
	for(int rowNum1=2; rowNum1<=10; rowNum1++) {
		
	String formId=reader.getCellData("Merged", "Form Id", rowNum1);
	String lEADID=reader.getCellData("Merged", "LEADID", rowNum1);
	String lEADNAME=reader.getCellData("Merged", "LEADNAME", rowNum1);
	String status=reader.getCellData("Merged", "Status", rowNum1);
	
	Object ob[]= {formId,	lEADID,	lEADNAME,	status};
		myData.add(ob);
	}

return myData;
}
	
	
	
	
	
}