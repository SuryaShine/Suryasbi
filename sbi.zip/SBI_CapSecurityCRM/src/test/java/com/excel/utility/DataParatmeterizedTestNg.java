package com.excel.utility;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataParatmeterizedTestNg {

	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	TestUtility.getDataFromExcel();
	return testData.iterator();
	}
	
	
	@Test(dataProvider="getTestData")
	public void dataProviderTest(String formId ,String leadId, String leadName ,String status ) {
		
		
		System.out.println(formId);
		System.out.println(leadId);
		System.out.println(leadName);
		System.out.println(status);
		
		
	}
	
}
