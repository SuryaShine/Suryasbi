package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.IticketPage;
import com.crm.qa.pages.LoginCRMPage;
import com.crm.qa.util.TestUtil;

public class Inward_IticketPage extends TestBase {

	IticketPage itiketPage;
	TestUtil testUtil;
	
	
	@Test(priority=1)
	public void login_Inward() {
		initialization();
		itiketPage = new IticketPage();
	}
	
	
	
	@Test(priority=3)
	public void loginTest() {
	//	homepage = login_crmpage.loginCRM(prop.getProperty("url_CRM"),prop.getProperty("username_CRM"), prop.getProperty("password_CRM"));
		itiketPage.login_Iticket(prop.getProperty("url_ITicket"),prop.getProperty("username_Inward"), prop.getProperty("password_Inward"));
	}
	
	
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"),prop.getProperty("FORM_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	@Test(priority=4,dataProvider="getTestData")
	public void inwardDone(String formId, int rowNo) {
		
		try {
			itiketPage.inwardAccept(formId, rowNo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.assertTrue(false);
		}
		
	}
	
	
}
