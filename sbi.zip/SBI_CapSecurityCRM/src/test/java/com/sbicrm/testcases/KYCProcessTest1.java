package com.sbicrm.testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.sbicrm.qa.pages.KYCPage;

public class KYCProcessTest1  extends KYCPage {

	
	WebDriver driver;
	KYCPage kycpage =new KYCPage();
	
	
	
	
	@Test(priority=1)
	public void loginCRMPage() {
		kycpage.loginCRM();
	}
	
	
	@Test(priority=2)
	public void callStatusPositiveTest() throws InterruptedException
	{
		
			kycpage.CallStatusPositive();
		
	}
	
	
	}
	

