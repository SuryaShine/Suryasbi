package com.crm.qa.testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.LoginCRMPage;
import com.crm.qa.util.TestUtil;

public class LoginCRMPageTest extends TestBase {
	LoginCRMPage login_crmpage;
	
	
	TestUtil testUtil;

	public LoginCRMPageTest() {
		super();
	}

	
	  @Test(priority=1) public void login_CRM() { initialization(); login_crmpage =
	  new LoginCRMPage(); }
	 

	/*
	 * @Test(priority = 1) public void loginPageTitleTest() { String title =
	 * loginpage.validateLoginPageTitle(); Assert.assertEquals(title,
	 * "#1 Free CRM for Any Business: Online Customer Relationship Software"); }
	 * 
	 * @Test(priority = 2) public void crmLogoImageTest() { boolean flag =
	 * loginpage.validateCRMImage(); Assert.assertTrue(flag);
	}*/

	
	
	// running
	
	@Test(priority=2)
	public void loginTest() {
	//	homepage = login_crmpage.loginCRM(prop.getProperty("url_CRM"),prop.getProperty("username_CRM"), prop.getProperty("password_CRM"));
		login_crmpage.loginCRM(prop.getProperty("url_CRM"),prop.getProperty("username_CRM"), prop.getProperty("password_CRM"));
	}

	
	  
	
	@DataProvider
	public Iterator<Object[]> getTestData() {
	ArrayList<Object[]> testData=	testUtil.getDataFromExcel(prop.getProperty("SHEET_NAME"), prop.getProperty("LEAD_ID"));   //pass arguments as sheetName and colName
	return testData.iterator();
	}
	
	
	
	
	@Test(priority=4,dataProvider="getTestData")
	public void sendToPreKYC(String leadId, int romNumber) {
		
		try {
			login_crmpage.sendToPreKYC(leadId,romNumber);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			Assert.assertTrue(true);
		}
		
	} 
	
/*
	@Test(priority=6,dataProvider="getTestData")
	public void kyc_TeleCallerProcess(String leadID, int rowNo ) {
		
			try {
				login_crmpage.kyc_TeleCallerProcess(leadID, rowNo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			*/
	
	
	  @Test(priority=7)
	  public void tearDown() { driver.quit(); }

}
	

