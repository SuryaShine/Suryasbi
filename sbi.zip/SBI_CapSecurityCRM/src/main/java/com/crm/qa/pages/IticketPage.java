package com.crm.qa.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.TestUtil;

public class IticketPage extends TestBase{

	TestUtil testUtil;
	WebDriverWait wait;
	
	@FindBy(xpath="//input[@placeholder='Username or Email']")
	WebElement username_Itckt;

@FindBy(xpath="//input[@placeholder='Password']") WebElement password_Itckt;

@FindBy(xpath="//a[@class='btn btn-primary']") WebElement loginBtn_Itckt;


@FindBy(xpath="//input[@id='formno']") WebElement txtFormNumber  ;

@FindBy(xpath="//button[@class='btn btn-default']") WebElement searchBtn;
	
//Initializing the Page objects:
public IticketPage(){
	this.driver=driver;
	wait = new WebDriverWait(driver,30);
	PageFactory.initElements(driver, this);
	
}



public void login_Iticket(String url,String un ,String pwd)  {
	
	driver.get(url);
	username_Itckt.sendKeys(un);
	
	//wait.until(ExpectedConditions.presenceOfElementLocated(username_Itckt)).
	
	password_Itckt.sendKeys(pwd);

	loginBtn_Itckt.click();
	
	//wait.until(ExpectedConditions.elementToBeClickable(loginBtn_Itckt));
}

public void inwardAccept(String formId, int rowNum ) throws InterruptedException {
	
	
	String kyc_Status=  testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("KYC_STATUS"), rowNum);
	
	if(kyc_Status.contains("KYC_Done"))
	{
		
	String inwardStatus =testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("INWARDd_STATUS"), rowNum);
	
	
	if(!inwardStatus.contains("Inwds_Done")){
	txtFormNumber.clear();
	Thread.sleep(1000);
	txtFormNumber.sendKeys(formId);
	Thread.sleep(1000);
	txtFormNumber.sendKeys(Keys.ENTER);
	//txtFormNumber.sendKeys(Keys.RETURN);
	Thread.sleep(1000);
	//searchBtn.click();
	
			Alert alert = driver.switchTo().alert();
			Thread.sleep(1000);
			
		String txtalrtmsg=	alert.getText();
		
		if(txtalrtmsg.contains("Inward is already done for this form."))
			
		{
			System.out.print(txtalrtmsg);
			alert.dismiss();
			
			Thread.sleep(100);
			
		}else {
			System.out.print(txtalrtmsg);
			alert.accept();
		
Thread.sleep(1000);
testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("INWARDd_STATUS"), rowNum, "Inwds_Done");
	}
	}
}
}



@FindBy(xpath="//input[@id='secontForm']") WebElement txtFormNum_verify  ;

@FindBy(xpath="//body/app-root/app-welcome/div[@class='container-fluid main-content']/fieldset/div[@class='col-lg-6']/div[@class='widget-container fluid-height clearfix']/div[@class='heading']/div[@class='form-group']/div[@class='col-md-7']/div[@class='input-group']/span[@class='input-group-btn']/button[1] ") 

WebElement searchBtnVrify;
	

public void verify_kcy(String formId, int rowNum ) throws InterruptedException {
	
	
	String inward_Status=  testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("INWARDd_STATUS"), rowNum);
	
	if(inward_Status.contains("Inwds_Done"))
	{
		
		String verifyStatus =testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("VERIFY_STATUS"), rowNum);
		
		
		if(!verifyStatus.contains("Verify_Done")){
		
		txtFormNum_verify.clear();
	
		txtFormNum_verify.sendKeys(formId);
	Thread.sleep(1000);
	txtFormNum_verify.sendKeys(Keys.ENTER);
			//elem.sendKeys(Keys.RETURN);
	Thread.sleep(1000);
			Alert alert = driver.switchTo().alert();
			//String txtalertmsg= alert.getText();
			
			alert.accept(); 
			
			Thread.sleep(1000);
testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("VERIFY_STATUS"), rowNum, "Verify_Done");
			
				


	}
}
}	



@FindBy(xpath="//input[@id='secontForm']") WebElement txtFormDataEntryy  ;

	public void dataEntry(String formId, int rowNum ) throws InterruptedException {
		
		
		String verify_Status=  testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("VERIFY_STATUS"), rowNum);
		
		if(verify_Status.contains("Verify_Done")) {
		
			txtFormDataEntryy.clear();
		
			txtFormDataEntryy.sendKeys(formId);
			//Thread.sleep(1000);
		
			//txtFormDataEntryy.sendKeys(Keys.ENTER);
				//elem.sendKeys(Keys.RETURN);
	
		Thread.sleep(2000);
				Alert alert = driver.switchTo().alert();
				Thread.sleep(1000);
				alert.accept();
			
	Thread.sleep(1000);
	testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("DATAENTRY_STATUS"), rowNum, "DataEntry_Done");
		}
	

	
	}


	
	
	
	
	
	@FindBy(xpath="//input[@id='secontForm']") WebElement txtFormAuth  ;

	public void authDone(String formId, int rowNum ) throws InterruptedException {
		
		
		String dataEntry_Status=  testUtil.reader.getCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("DATAENTRY_STATUS"), rowNum);
		
		if(dataEntry_Status.contains("DataEntry_Done")) {
		
			txtFormAuth.clear();
		
			txtFormAuth.sendKeys(formId);
			//Thread.sleep(1000);
		
			//txtFormDataEntryy.sendKeys(Keys.ENTER);
				//elem.sendKeys(Keys.RETURN);
	
		Thread.sleep(2000);
				Alert alert = driver.switchTo().alert();
				Thread.sleep(1000);
				alert.accept();
			
	Thread.sleep(1000);
	testUtil.reader.setCellData(prop.getProperty("SHEET_NAME"), prop.getProperty("AUTH_STATUS"), rowNum, "Auth_Done");
		}
	

	
	}
	
	







}

