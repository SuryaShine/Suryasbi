package com.sbicrm.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.excel.utility.Xls_Reader;

public class KYCPage {
	
	
public static WebDriver driver=null;

   
   By emailId = By.xpath("//input[@class='textbox' and @name='UserName']");
   By password = By.xpath("//input[@id='TxtPassword' ]");
   By loginButton = By.xpath("//input[@value='login' ]");
	public void loginCRM() {
		System.setProperty("webdriver.chrome.driver","E:\\Gargi\\Selenium\\Drivers\\Chrome Driver\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\eclipse-workspace\\SBI_CapSecurityCRM\\Drivers\\chromedriver.exe");
		
	    WebDriver driver = new ChromeDriver();
	    
	 // launch Chrome and redirect it to the Base URL
	 		driver.get("https://crmn.sbismart.com/bcg/sn/app/login/login?logout=1");
		
	  //Maximizes the browser window
	  		driver.manage().window().maximize();
	  		driver.findElement(emailId).clear();
			driver.findElement(emailId).sendKeys("br_anitad");  //UserId
			driver.findElement(password).clear();
			driver.findElement(password).sendKeys("acid_qa");   //Password
			
			driver.findElement(loginButton).click();	
			
	}
	

	
	
	
	 Xls_Reader	 reader = new Xls_Reader("C://Users//User//eclipse-workspace//SBI_CapSecurityCRM//src//main//java//com//crm//qa//testdata//SbiCRMUATList.xlsx");
	
	
	int rowCount = reader.getRowCount("Shine"); 
	
	
	
	
	
	
	   
	  
	
	public void CallStatusPositive() throws InterruptedException {
		
		System.out.println(rowCount);
		
		
		By searchBtn1st= By.xpath("//i[@class='icon icon-header-search-bar-icon']");

		By txtLeadId  = By.xpath("//input[@id='LeadID']");

		By searchBtn2nd= By.xpath("//input[@id='srchBtn']");

		By editBtn= By.xpath("//a[@id='BTN_EDIT']//i[@class='icon icon-edit']");

		   By callStatus1= By.xpath("//select[@id='LEA_EX2_63']");
		   By callStatus2= By.xpath("//select[@id='LEA_EX2_64']");
		   By callStatus3= By.xpath("//select[@id='LEA_EX2_65']");
		   By callStatus4= By.xpath("//select[@id='LEA_EX2_66']");
		   By SaveAndProceedBtn= By.xpath("//span[contains(text(),'Save and Proceed')]");
		   
		   
		   By status = By.xpath("//div[@class='row row-margin0']//div[4]//span[1]");
		
		
		for(int rowNum=2; rowNum<=rowCount; rowNum++) {
			  System.out.println(".............");
		
			  driver.findElement(By.xpath("//i[@class='icon icon-header-search-bar-icon']")).click();
	     
			String leadIdstr = reader.getCellData("Merged", "LEADID", rowNum);  //  excelsheet hard
			
			System.out.println(leadIdstr);
			
			Double leadId1 = Double.valueOf(leadIdstr);
			System.out.println(leadId1);
			
			//int leadId=Integer.parseInt(leadId1); 
			
			int leadId2 = leadId1.intValue();
			
			System.out.println(leadId2);
			
			String leadId = Integer.toString(leadId2); 
			System.out.println(leadId);
			
			driver.findElement(txtLeadId).clear();
			driver.findElement(txtLeadId).sendKeys(leadId);
			driver.findElement(searchBtn2nd).click();
			
			
			Thread.sleep(1000);
		driver.findElement(editBtn).click();
		Thread.sleep(1000);
			
		Select dropdown1 = new Select(driver.findElement(callStatus1)); 
		dropdown1.selectByVisibleText("Picked Up");
		
		
		Select dropdown2 = new Select(driver.findElement(callStatus2)); 
		
		dropdown2.selectByVisibleText("Right Person");
		
		Thread.sleep(2000);
			
		Select dropdown3 = new Select(driver.findElement(callStatus3)); 
		dropdown3.selectByVisibleText("Not Busy");
		
		Select dropdown4 = new Select(driver.findElement(callStatus4)); 
		dropdown4.selectByVisibleText("Approved For A/c opening - Correct Email ID & Scheme");
		
		driver.findElement(SaveAndProceedBtn).click();
		
		;   //excelSheet  hard	
	}
	}
	
	
	
	
	
}
