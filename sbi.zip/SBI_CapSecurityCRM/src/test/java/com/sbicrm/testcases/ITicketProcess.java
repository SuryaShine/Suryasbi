package com.sbicrm.testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.excel.utility.Xls_Reader;

public class ITicketProcess {

	
	
	public static	WebDriver driver=null;
	


	By userName= By.xpath("//input[@placeholder='Username or Email']");
	By password = By.xpath("//input[@placeholder='Password']");
	By loginButton = By.xpath("//a[@class='btn btn-primary']");
	
By txtFormNumber= By.xpath("//input[@id='formno']");


Xls_Reader reader = new Xls_Reader("C://Users//User//eclipse-workspace//SBI_CapSecurityCRM//src//main//java//com//crm//qa//testdata//SbiCRMUATList.xlsx");

int rowCount = reader.getRowCount("Surya");




//Inward Process
	@Test(priority=1)
		public void inward() throws InterruptedException {
			
			  
	System.setProperty("webdriver.chrome.driver","E:\\Gargi\\Selenium\\Drivers\\Chrome Driver\\chromedriver.exe");
			//System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\eclipse-workspace\\SBI_CapSecurityCRM\\Drivers\\chromedriver.exe");
			
		     driver = new ChromeDriver();
			
		  //Maximizes the browser window
		  		driver.manage().window().maximize();
		    
			// launch Chrome and redirect it to the Base URL
			driver.get("https://app.sbismart.com/iticketbcguatv2/login");
			
			
			
			driver.findElement(userName).clear();
			driver.findElement(userName).sendKeys("osk1105");
			driver.findElement(password).clear();
			driver.findElement(password).sendKeys("P@ssw0rd");
			driver.findElement(loginButton).click();
			
			
			
			
		
			/*for(int rowNum=2; rowNum<=rowCount; rowNum++) {
				
			System.out.println(rowCount);
			String formId = reader.getCellData("Shine", "Form Id", rowNum);
			
			System.out.println(formId);*/
			
			Thread.sleep(2000);
			driver.findElement(txtFormNumber).clear();
			
			
			WebElement elem = driver.findElement(txtFormNumber);
			Thread.sleep(2000);
			elem.sendKeys("54386");
			
					//elem.sendKeys(Keys.ENTER);
					//elem.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//button[@class='btn btn-default']")).click();
			Thread.sleep(1000);
					Alert alert = driver.switchTo().alert();
					           alert.accept();
		Thread.sleep(2000);
		reader.setCellData("Surya", "InwardStatus", 2 , "Inwds_Done");
		
	    
	}
			
	
	
	
	/*
	
	
	@Test(priority=2)
	public void verify() {
		  
	System.setProperty("webdriver.chrome.driver","E:\\Gargi\\Selenium\\Drivers\\Chrome Driver\\chromedriver.exe");
			//System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\eclipse-workspace\\SBI_CapSecurityCRM\\Drivers\\chromedriver.exe");
			
		     driver = new ChromeDriver();
			
		  //Maximizes the browser window
		  		driver.manage().window().maximize();
		    
			// launch Chrome and redirect it to the Base URL
			driver.get("https://app.sbismart.com/iticketbcguatv2/login");
			
			
			
			driver.findElement(userName).clear();
			driver.findElement(userName).sendKeys("verify");
			driver.findElement(password).clear();
			driver.findElement(password).sendKeys("P@ssw0rd");
			driver.findElement(loginButton).click();
		
	}
	*/
}
