package com.qa.crm.createLeads;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;



public class CreateLeads {

	
	@Test()
	public void login() throws InterruptedException {
		
		  
	System.setProperty("webdriver.chrome.driver","E:\\Gargi\\Selenium\\Drivers\\Chrome Driver\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\eclipse-workspace\\SBI_CapSecurityCRM\\Drivers\\chromedriver.exe");
		
	    WebDriver driver = new ChromeDriver();
		
	  //Maximizes the browser window
	  		driver.manage().window().maximize();
	    
		// launch Chrome and redirect it to the Base URL
		driver.get("https://crmn.sbismart.com/bcg/sn/app/login/login?logout=1");
		
		By emailId = By.xpath("//input[@class='textbox' and @name='UserName']");
		By password = By.xpath("//input[@id='TxtPassword' ]");
		By loginButton = By.xpath("//input[@value='login' ]");
		By searchBtn1st= By.xpath("//i[@class='icon icon-header-search-bar-icon']");
		
		By txtLeadId  = By.xpath("//input[@id='LeadID']");
		
		By searchBtn2nd= By.xpath("//input[@id='srchBtn']");
		
		By editBtn= By.xpath("//a[@id='BTN_EDIT']//i[@class='icon icon-edit']");
		
		   By callStatus1= By.xpath("//select[@id='LEA_EX2_63']");
		   By callStatus2= By.xpath("//select[@id='LEA_EX2_64']");
		   By callStatus3= By.xpath("//select[@id='LEA_EX2_65']");
		   By callStatus4= By.xpath("//select[@id='LEA_EX2_66']");
		   By clickOnLeads=By.xpath("//i[@class='icon icon-obj6']//span[@class='icon-bg bg-base-standard']");
		
		
		driver.findElement(emailId).clear();
		driver.findElement(emailId).sendKeys("osk1205");
		driver.findElement(password).clear();
		driver.findElement(password).sendKeys("acid_qa");
		driver.findElement(loginButton).click();
		
		Thread.sleep(2000);
	driver.findElement(clickOnLeads).click();
	 Thread.sleep(2000);
	 

		
		}
	}
	
	
	

